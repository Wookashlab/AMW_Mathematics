﻿namespace AMW_Mathematics
{
    partial class Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Interface));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button87 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button43 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button42 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button92 = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button89 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.k6 = new System.Windows.Forms.PictureBox();
            this.Kalkulator = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.k0 = new System.Windows.Forms.PictureBox();
            this.k1 = new System.Windows.Forms.PictureBox();
            this.k4 = new System.Windows.Forms.PictureBox();
            this.k7 = new System.Windows.Forms.PictureBox();
            this.kKropka = new System.Windows.Forms.PictureBox();
            this.k2 = new System.Windows.Forms.PictureBox();
            this.k5 = new System.Windows.Forms.PictureBox();
            this.k8 = new System.Windows.Forms.PictureBox();
            this.k9 = new System.Windows.Forms.PictureBox();
            this.k3 = new System.Windows.Forms.PictureBox();
            this.kPrzecinek = new System.Windows.Forms.PictureBox();
            this.KDzielenie = new System.Windows.Forms.PictureBox();
            this.kMnozenie = new System.Windows.Forms.PictureBox();
            this.kDodawanie = new System.Windows.Forms.PictureBox();
            this.kOdejmowanie = new System.Windows.Forms.PictureBox();
            this.kEnter = new System.Windows.Forms.PictureBox();
            this.kBksp = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.k6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kalkulator)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kKropka)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kPrzecinek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KDzielenie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kMnozenie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kDodawanie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kOdejmowanie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kEnter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kBksp)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(1, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1110, 131);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1102, 105);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "File";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1102, 105);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Home";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button11);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Location = new System.Drawing.Point(768, 7);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(331, 95);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Input";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(231, 20);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(69, 62);
            this.button11.TabIndex = 3;
            this.button11.Text = "Unit Converter";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(156, 19);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(69, 62);
            this.button10.TabIndex = 2;
            this.button10.Text = "Triangle Solver";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(81, 20);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(69, 62);
            this.button8.TabIndex = 1;
            this.button8.Text = "Formulas and Equations";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(6, 20);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(69, 62);
            this.button9.TabIndex = 0;
            this.button9.Text = "Equation Solver";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Location = new System.Drawing.Point(608, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(154, 95);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Input";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(77, 20);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(72, 62);
            this.button7.TabIndex = 1;
            this.button7.Text = "Ink";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(6, 20);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(69, 62);
            this.button6.TabIndex = 0;
            this.button6.Text = "Keyboard";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.flowLayoutPanel1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(140, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(462, 95);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Numbers  Angles";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.radioButton3);
            this.flowLayoutPanel1.Controls.Add(this.radioButton4);
            this.flowLayoutPanel1.Controls.Add(this.radioButton5);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(123, 16);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(125, 73);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(3, 3);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(65, 17);
            this.radioButton3.TabIndex = 0;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Degrees";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(3, 26);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(64, 17);
            this.radioButton4.TabIndex = 1;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Radians";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(3, 49);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(67, 17);
            this.radioButton5.TabIndex = 2;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Gradians";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(254, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Decimal Places";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Not Fixed",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13"});
            this.comboBox1.Location = new System.Drawing.Point(350, 16);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(92, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 42);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(110, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Complex Numbers";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(92, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Real Numbers";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(7, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(127, 95);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Clipboard";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(79, 68);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(42, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Copy";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(79, 39);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(42, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Cut";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(79, 10);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(42, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Paste";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(7, 49);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(42, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Redo";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Undo";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Controls.Add(this.groupBox10);
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1102, 105);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Insert";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button87);
            this.groupBox11.Location = new System.Drawing.Point(217, 9);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(99, 93);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Data Sets";
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(7, 19);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(86, 68);
            this.button87.TabIndex = 0;
            this.button87.Text = "Data Set";
            this.button87.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button43);
            this.groupBox10.Location = new System.Drawing.Point(112, 9);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(99, 93);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Variables";
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(7, 19);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(86, 68);
            this.button43.TabIndex = 0;
            this.button43.Text = "Variable";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button42);
            this.groupBox9.Location = new System.Drawing.Point(7, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(99, 93);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Matrices";
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(7, 19);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(86, 68);
            this.button42.TabIndex = 0;
            this.button42.Text = "Matrix";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox14);
            this.tabPage4.Controls.Add(this.groupBox13);
            this.tabPage4.Controls.Add(this.groupBox12);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1102, 105);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "View";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.comboBox4);
            this.groupBox14.Controls.Add(this.button92);
            this.groupBox14.Location = new System.Drawing.Point(384, 9);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(181, 90);
            this.groupBox14.TabIndex = 3;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Zoom";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(7, 52);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(81, 21);
            this.comboBox4.TabIndex = 2;
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(94, 19);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(72, 65);
            this.button92.TabIndex = 1;
            this.button92.Text = "Stored Variables";
            this.button92.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button90);
            this.groupBox13.Controls.Add(this.button91);
            this.groupBox13.Location = new System.Drawing.Point(197, 9);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(181, 90);
            this.groupBox13.TabIndex = 2;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Show";
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(94, 19);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(72, 65);
            this.button90.TabIndex = 1;
            this.button90.Text = "Stored Variables";
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(6, 19);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(72, 65);
            this.button91.TabIndex = 0;
            this.button91.Text = "Calculator Pad";
            this.button91.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button89);
            this.groupBox12.Controls.Add(this.button88);
            this.groupBox12.Location = new System.Drawing.Point(10, 9);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(181, 90);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Apperance";
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(94, 19);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(72, 65);
            this.button89.TabIndex = 1;
            this.button89.Text = "Corol Schemes";
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(6, 19);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(72, 65);
            this.button88.TabIndex = 0;
            this.button88.Text = "Skins";
            this.button88.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(234, 149);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(877, 648);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.listBox1);
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(869, 622);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Worksheet";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(11, 20);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(846, 381);
            this.listBox1.TabIndex = 1;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button13);
            this.groupBox5.Controls.Add(this.button12);
            this.groupBox5.Controls.Add(this.textBox2);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Location = new System.Drawing.Point(6, 414);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(857, 161);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(776, 61);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 3;
            this.button13.Text = "Enter";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(776, 29);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 2;
            this.button12.Text = "Clear";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(23, 114);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(828, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "Type an expression and then click Enter.";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(22, 29);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(748, 55);
            this.textBox1.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox8);
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.groupBox6);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(869, 622);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Graphing";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Location = new System.Drawing.Point(341, 197);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(522, 352);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(48, 181);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Examples";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(48, 116);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Bla bla bla ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(35, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(377, 42);
            this.label5.TabIndex = 0;
            this.label5.Text = "Help For Graphic Tab";
            // 
            // groupBox7
            // 
            this.groupBox7.Location = new System.Drawing.Point(341, 20);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(522, 161);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.button41);
            this.groupBox6.Controls.Add(this.button40);
            this.groupBox6.Controls.Add(this.button39);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.textBox4);
            this.groupBox6.Controls.Add(this.textBox3);
            this.groupBox6.Controls.Add(this.comboBox3);
            this.groupBox6.Controls.Add(this.comboBox2);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Location = new System.Drawing.Point(6, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(298, 555);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 400);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "Inequalities";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 483);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Graph Control";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 332);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Parametric";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 254);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Data Sets";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(220, 196);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(63, 23);
            this.button41.TabIndex = 9;
            this.button41.Text = "Graph";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(69, 196);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(63, 23);
            this.button40.TabIndex = 8;
            this.button40.Text = "Remove";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(16, 196);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(47, 23);
            this.button39.TabIndex = 7;
            this.button39.Text = "Add";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 143);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "1";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(32, 141);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(234, 20);
            this.textBox4.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(32, 112);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(234, 20);
            this.textBox3.TabIndex = 3;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(82, 51);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(159, 21);
            this.comboBox3.TabIndex = 2;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(9, 51);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(54, 21);
            this.comboBox2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Equations Functions";
            // 
            // k6
            // 
            this.k6.Image = ((System.Drawing.Image)(resources.GetObject("k6.Image")));
            this.k6.Location = new System.Drawing.Point(132, 683);
            this.k6.Name = "k6";
            this.k6.Size = new System.Drawing.Size(30, 21);
            this.k6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k6.TabIndex = 2;
            this.k6.TabStop = false;
            this.k6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k6.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k6.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // Kalkulator
            // 
            this.Kalkulator.Image = ((System.Drawing.Image)(resources.GetObject("Kalkulator.Image")));
            this.Kalkulator.Location = new System.Drawing.Point(1, 145);
            this.Kalkulator.Name = "Kalkulator";
            this.Kalkulator.Size = new System.Drawing.Size(234, 652);
            this.Kalkulator.TabIndex = 86;
            this.Kalkulator.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 412);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 182;
            this.label4.Text = "Standard";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 294);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 181;
            this.label3.Text = "Trigonometry";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 180;
            this.label2.Text = "Statistic";
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(169, 518);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(29, 23);
            this.button82.TabIndex = 179;
            this.button82.Text = "x";
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(134, 518);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(29, 23);
            this.button83.TabIndex = 178;
            this.button83.Text = "x";
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(99, 518);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(29, 23);
            this.button84.TabIndex = 177;
            this.button84.Text = "x";
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(64, 518);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(29, 23);
            this.button85.TabIndex = 176;
            this.button85.Text = "x";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(29, 518);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(29, 23);
            this.button86.TabIndex = 175;
            this.button86.Text = "x";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(169, 489);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(29, 23);
            this.button54.TabIndex = 174;
            this.button54.Text = "x";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(134, 489);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(29, 23);
            this.button55.TabIndex = 173;
            this.button55.Text = "x";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(99, 489);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(29, 23);
            this.button56.TabIndex = 172;
            this.button56.Text = "x";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(64, 489);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(29, 23);
            this.button57.TabIndex = 171;
            this.button57.Text = "x";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(29, 489);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(29, 23);
            this.button58.TabIndex = 170;
            this.button58.Text = "x";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(169, 460);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(29, 23);
            this.button49.TabIndex = 169;
            this.button49.Text = "x";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(134, 460);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(29, 23);
            this.button50.TabIndex = 168;
            this.button50.Text = "x";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(99, 460);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(29, 23);
            this.button51.TabIndex = 167;
            this.button51.Text = "x";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(64, 460);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(29, 23);
            this.button52.TabIndex = 166;
            this.button52.Text = "x";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(29, 460);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(29, 23);
            this.button53.TabIndex = 165;
            this.button53.Text = "x";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(169, 431);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(29, 23);
            this.button44.TabIndex = 164;
            this.button44.Text = "x";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(134, 431);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(29, 23);
            this.button45.TabIndex = 163;
            this.button45.Text = "x";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(99, 431);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(29, 23);
            this.button46.TabIndex = 162;
            this.button46.Text = "x";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(64, 431);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(29, 23);
            this.button47.TabIndex = 161;
            this.button47.Text = "x";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(29, 431);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(29, 23);
            this.button48.TabIndex = 160;
            this.button48.Text = "x";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(169, 373);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(29, 23);
            this.button34.TabIndex = 159;
            this.button34.Text = "x";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(134, 373);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(29, 23);
            this.button35.TabIndex = 158;
            this.button35.Text = "x";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(99, 373);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(29, 23);
            this.button36.TabIndex = 157;
            this.button36.Text = "x";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(64, 373);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(29, 23);
            this.button37.TabIndex = 156;
            this.button37.Text = "x";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(29, 373);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(29, 23);
            this.button38.TabIndex = 155;
            this.button38.Text = "x";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(169, 344);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(29, 23);
            this.button29.TabIndex = 154;
            this.button29.Text = "x";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(134, 344);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(29, 23);
            this.button30.TabIndex = 153;
            this.button30.Text = "x";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(99, 344);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(29, 23);
            this.button31.TabIndex = 152;
            this.button31.Text = "x";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(64, 344);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(29, 23);
            this.button32.TabIndex = 151;
            this.button32.Text = "x";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(29, 344);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(29, 23);
            this.button33.TabIndex = 150;
            this.button33.Text = "x";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(169, 315);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(29, 23);
            this.button24.TabIndex = 149;
            this.button24.Text = "x";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(134, 315);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(29, 23);
            this.button25.TabIndex = 148;
            this.button25.Text = "x";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(99, 315);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(29, 23);
            this.button26.TabIndex = 147;
            this.button26.Text = "x";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(64, 315);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(29, 23);
            this.button27.TabIndex = 146;
            this.button27.Text = "x";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(29, 315);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(29, 23);
            this.button28.TabIndex = 145;
            this.button28.Text = "x";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(169, 264);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(29, 23);
            this.button19.TabIndex = 144;
            this.button19.Text = "x";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(134, 264);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(29, 23);
            this.button20.TabIndex = 143;
            this.button20.Text = "x";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(99, 264);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(29, 23);
            this.button21.TabIndex = 142;
            this.button21.Text = "x";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(64, 264);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(29, 23);
            this.button22.TabIndex = 141;
            this.button22.Text = "x";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(29, 264);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(29, 23);
            this.button23.TabIndex = 140;
            this.button23.Text = "x";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(169, 235);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(29, 23);
            this.button18.TabIndex = 139;
            this.button18.Text = "x";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(134, 235);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(29, 23);
            this.button17.TabIndex = 138;
            this.button17.Text = "x";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(99, 235);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(29, 23);
            this.button16.TabIndex = 137;
            this.button16.Text = "x";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(64, 235);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(29, 23);
            this.button15.TabIndex = 136;
            this.button15.Text = "x";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(29, 235);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(29, 23);
            this.button14.TabIndex = 135;
            this.button14.Text = "x";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // k0
            // 
            this.k0.Image = ((System.Drawing.Image)(resources.GetObject("k0.Image")));
            this.k0.Location = new System.Drawing.Point(66, 735);
            this.k0.Name = "k0";
            this.k0.Size = new System.Drawing.Size(30, 21);
            this.k0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k0.TabIndex = 183;
            this.k0.TabStop = false;
            this.k0.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k0.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k0.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k0.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k1
            // 
            this.k1.Image = ((System.Drawing.Image)(resources.GetObject("k1.Image")));
            this.k1.Location = new System.Drawing.Point(66, 708);
            this.k1.Name = "k1";
            this.k1.Size = new System.Drawing.Size(30, 21);
            this.k1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k1.TabIndex = 184;
            this.k1.TabStop = false;
            this.k1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k1.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k1.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k4
            // 
            this.k4.Image = ((System.Drawing.Image)(resources.GetObject("k4.Image")));
            this.k4.Location = new System.Drawing.Point(66, 683);
            this.k4.Name = "k4";
            this.k4.Size = new System.Drawing.Size(30, 21);
            this.k4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k4.TabIndex = 185;
            this.k4.TabStop = false;
            this.k4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k4.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k4.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k7
            // 
            this.k7.Image = ((System.Drawing.Image)(resources.GetObject("k7.Image")));
            this.k7.Location = new System.Drawing.Point(66, 658);
            this.k7.Name = "k7";
            this.k7.Size = new System.Drawing.Size(30, 21);
            this.k7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k7.TabIndex = 186;
            this.k7.TabStop = false;
            this.k7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k7.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k7.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kKropka
            // 
            this.kKropka.Image = ((System.Drawing.Image)(resources.GetObject("kKropka.Image")));
            this.kKropka.Location = new System.Drawing.Point(100, 735);
            this.kKropka.Name = "kKropka";
            this.kKropka.Size = new System.Drawing.Size(30, 21);
            this.kKropka.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kKropka.TabIndex = 187;
            this.kKropka.TabStop = false;
            this.kKropka.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.kKropka.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kKropka.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kKropka.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k2
            // 
            this.k2.Image = ((System.Drawing.Image)(resources.GetObject("k2.Image")));
            this.k2.Location = new System.Drawing.Point(100, 707);
            this.k2.Name = "k2";
            this.k2.Size = new System.Drawing.Size(30, 21);
            this.k2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k2.TabIndex = 188;
            this.k2.TabStop = false;
            this.k2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k2.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k2.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k5
            // 
            this.k5.Image = ((System.Drawing.Image)(resources.GetObject("k5.Image")));
            this.k5.Location = new System.Drawing.Point(100, 684);
            this.k5.Name = "k5";
            this.k5.Size = new System.Drawing.Size(30, 21);
            this.k5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k5.TabIndex = 189;
            this.k5.TabStop = false;
            this.k5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k5.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k5.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k8
            // 
            this.k8.Image = ((System.Drawing.Image)(resources.GetObject("k8.Image")));
            this.k8.Location = new System.Drawing.Point(100, 658);
            this.k8.Name = "k8";
            this.k8.Size = new System.Drawing.Size(30, 21);
            this.k8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k8.TabIndex = 190;
            this.k8.TabStop = false;
            this.k8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k8.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k8.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k9
            // 
            this.k9.Image = ((System.Drawing.Image)(resources.GetObject("k9.Image")));
            this.k9.Location = new System.Drawing.Point(132, 658);
            this.k9.Name = "k9";
            this.k9.Size = new System.Drawing.Size(30, 21);
            this.k9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k9.TabIndex = 191;
            this.k9.TabStop = false;
            this.k9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k9.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k9.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // k3
            // 
            this.k3.Image = ((System.Drawing.Image)(resources.GetObject("k3.Image")));
            this.k3.Location = new System.Drawing.Point(132, 708);
            this.k3.Name = "k3";
            this.k3.Size = new System.Drawing.Size(30, 21);
            this.k3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.k3.TabIndex = 192;
            this.k3.TabStop = false;
            this.k3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.k3.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.k3.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.k3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kPrzecinek
            // 
            this.kPrzecinek.Image = ((System.Drawing.Image)(resources.GetObject("kPrzecinek.Image")));
            this.kPrzecinek.Location = new System.Drawing.Point(133, 735);
            this.kPrzecinek.Name = "kPrzecinek";
            this.kPrzecinek.Size = new System.Drawing.Size(30, 21);
            this.kPrzecinek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kPrzecinek.TabIndex = 193;
            this.kPrzecinek.TabStop = false;
            this.kPrzecinek.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.kPrzecinek.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kPrzecinek.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kPrzecinek.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // KDzielenie
            // 
            this.KDzielenie.Image = ((System.Drawing.Image)(resources.GetObject("KDzielenie.Image")));
            this.KDzielenie.Location = new System.Drawing.Point(164, 658);
            this.KDzielenie.Name = "KDzielenie";
            this.KDzielenie.Size = new System.Drawing.Size(35, 20);
            this.KDzielenie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.KDzielenie.TabIndex = 194;
            this.KDzielenie.TabStop = false;
            this.KDzielenie.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.KDzielenie.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.KDzielenie.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.KDzielenie.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kMnozenie
            // 
            this.kMnozenie.Image = ((System.Drawing.Image)(resources.GetObject("kMnozenie.Image")));
            this.kMnozenie.Location = new System.Drawing.Point(165, 684);
            this.kMnozenie.Name = "kMnozenie";
            this.kMnozenie.Size = new System.Drawing.Size(35, 20);
            this.kMnozenie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kMnozenie.TabIndex = 195;
            this.kMnozenie.TabStop = false;
            this.kMnozenie.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.kMnozenie.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kMnozenie.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kMnozenie.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kDodawanie
            // 
            this.kDodawanie.Image = ((System.Drawing.Image)(resources.GetObject("kDodawanie.Image")));
            this.kDodawanie.Location = new System.Drawing.Point(165, 708);
            this.kDodawanie.Name = "kDodawanie";
            this.kDodawanie.Size = new System.Drawing.Size(35, 20);
            this.kDodawanie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kDodawanie.TabIndex = 196;
            this.kDodawanie.TabStop = false;
            this.kDodawanie.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.kDodawanie.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kDodawanie.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kDodawanie.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kOdejmowanie
            // 
            this.kOdejmowanie.Image = ((System.Drawing.Image)(resources.GetObject("kOdejmowanie.Image")));
            this.kOdejmowanie.Location = new System.Drawing.Point(165, 735);
            this.kOdejmowanie.Name = "kOdejmowanie";
            this.kOdejmowanie.Size = new System.Drawing.Size(35, 20);
            this.kOdejmowanie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kOdejmowanie.TabIndex = 197;
            this.kOdejmowanie.TabStop = false;
            this.kOdejmowanie.MouseDown += new System.Windows.Forms.MouseEventHandler(this.klaw_MouseDown);
            this.kOdejmowanie.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kOdejmowanie.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kOdejmowanie.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kEnter
            // 
            this.kEnter.Image = ((System.Drawing.Image)(resources.GetObject("kEnter.Image")));
            this.kEnter.Location = new System.Drawing.Point(97, 760);
            this.kEnter.Name = "kEnter";
            this.kEnter.Size = new System.Drawing.Size(85, 33);
            this.kEnter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kEnter.TabIndex = 2;
            this.kEnter.TabStop = false;
            this.kEnter.MouseDown += new System.Windows.Forms.MouseEventHandler(this.kEnter_MouseDown);
            this.kEnter.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kEnter.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kEnter.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // kBksp
            // 
            this.kBksp.Image = ((System.Drawing.Image)(resources.GetObject("kBksp.Image")));
            this.kBksp.Location = new System.Drawing.Point(49, 760);
            this.kBksp.Name = "kBksp";
            this.kBksp.Size = new System.Drawing.Size(47, 32);
            this.kBksp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kBksp.TabIndex = 2;
            this.kBksp.TabStop = false;
            this.kBksp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bBksp_Click);
            this.kBksp.MouseEnter += new System.EventHandler(this.klaw_MouseEnter);
            this.kBksp.MouseLeave += new System.EventHandler(this.klaw_MouseLeave);
            this.kBksp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.klawa_MouseUp);
            // 
            // Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1115, 799);
            this.Controls.Add(this.kBksp);
            this.Controls.Add(this.kEnter);
            this.Controls.Add(this.kOdejmowanie);
            this.Controls.Add(this.kDodawanie);
            this.Controls.Add(this.kMnozenie);
            this.Controls.Add(this.KDzielenie);
            this.Controls.Add(this.kPrzecinek);
            this.Controls.Add(this.k3);
            this.Controls.Add(this.k9);
            this.Controls.Add(this.k8);
            this.Controls.Add(this.k5);
            this.Controls.Add(this.k2);
            this.Controls.Add(this.kKropka);
            this.Controls.Add(this.k7);
            this.Controls.Add(this.k4);
            this.Controls.Add(this.k1);
            this.Controls.Add(this.k0);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.k6);
            this.Controls.Add(this.Kalkulator);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl1);
            this.KeyPreview = true;
            this.Name = "Interface";
            this.Text = "AMW Mathematics";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Interface_KeyDown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.k6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kalkulator)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kKropka)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kPrzecinek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KDzielenie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kMnozenie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kDodawanie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kOdejmowanie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kEnter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kBksp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox k6;
        private System.Windows.Forms.PictureBox Kalkulator;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox k0;
        private System.Windows.Forms.PictureBox k1;
        private System.Windows.Forms.PictureBox k4;
        private System.Windows.Forms.PictureBox k7;
        private System.Windows.Forms.PictureBox kKropka;
        private System.Windows.Forms.PictureBox k2;
        private System.Windows.Forms.PictureBox k5;
        private System.Windows.Forms.PictureBox k8;
        private System.Windows.Forms.PictureBox k9;
        private System.Windows.Forms.PictureBox k3;
        private System.Windows.Forms.PictureBox kPrzecinek;
        private System.Windows.Forms.PictureBox KDzielenie;
        private System.Windows.Forms.PictureBox kMnozenie;
        private System.Windows.Forms.PictureBox kDodawanie;
        private System.Windows.Forms.PictureBox kOdejmowanie;
        private System.Windows.Forms.PictureBox kEnter;
        private System.Windows.Forms.PictureBox kBksp;
    }
}

